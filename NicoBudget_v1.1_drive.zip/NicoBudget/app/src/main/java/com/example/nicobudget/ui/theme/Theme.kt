package com.example.nicobudget.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun NicoBudgetTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}
