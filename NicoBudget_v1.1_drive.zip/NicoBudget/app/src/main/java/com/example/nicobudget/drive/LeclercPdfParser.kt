package com.example.nicobudget.drive

import android.content.Context
import android.net.Uri
import com.example.nicobudget.data.model.ParsedDriveLine
import com.example.nicobudget.data.model.ParsedDriveOrder
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper

/**
 * Parse un bon de commande Leclerc Drive (PDF) en [ParsedDriveOrder].
 * Logique validée sur les bons de commande réels (format 2026).
 */
object LeclercPdfParser {

    private val RE_HEADER = Regex(
        """commande n°(\d+) du (\d{2}/\d{2}/\d{4}) à (\d{1,2})h(\d{2}) \((\d+) produits?\)"""
    )
    private val RE_RAYON = Regex(
        """^([A-ZÀ-ÖØ-Þ0-9' \-&]+?) \((\d+) produits?\)"""
    )
    // libellé + quantité (entière ou décimale, produits au poids) + PU + total
    private val RE_PRODUIT = Regex(
        """^(.+?) (\d+(?:[.,]\d{1,3})?) (\d+[.,]\d{2}) (\d+[.,]\d{2})$"""
    )
    private val RE_TOTAL = Regex("""Total de la commande : (\d+[.,]\d{2})""")
    private val RE_ECONOMIES = Regex("""économiser (\d+[.,]\d{2}) €""")
    private val RE_TICKET = Regex("""gagné (\d+[.,]\d{2}) € en Ticket E\.Leclerc""")
    private val RE_MAGASIN = Regex("""au drive ([A-ZÀ-ÖØ-Þ\- ']+)""")

    private fun String.eur(): Double = replace(',', '.').toDouble()

    @Volatile
    private var initialized = false

    private fun ensureInit(context: Context) {
        if (!initialized) synchronized(this) {
            if (!initialized) {
                PDFBoxResourceLoader.init(context.applicationContext)
                initialized = true
            }
        }
    }

    /** @throws IllegalArgumentException si le PDF n'est pas un bon de commande reconnu. */
    fun parse(context: Context, uri: Uri): ParsedDriveOrder {
        ensureInit(context)
        val text = context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Impossible d'ouvrir le fichier." }
            PDDocument.load(input).use { doc ->
                PDFTextStripper().apply { sortByPosition = true }.getText(doc)
            }
        }
        return parseText(text)
    }

    internal fun parseText(text: String): ParsedDriveOrder {
        val header = RE_HEADER.find(text)
            ?: throw IllegalArgumentException(
                "Ce PDF ne ressemble pas à un bon de commande Leclerc Drive."
            )
        val (orderId, dateFr, hour, minute, count) = header.destructured
        val (d, m, y) = dateFr.split("/")

        val lines = mutableListOf<ParsedDriveLine>()
        var section: String? = null
        var inDetail = false
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("Détail de votre commande") -> inDetail = true
                !inDetail -> {}
                line.startsWith("Total de la commande") -> break
                else -> {
                    val rayon = RE_RAYON.find(line)
                    if (rayon != null) {
                        section = rayon.groupValues[1].trim()
                            .lowercase().replaceFirstChar { it.uppercase() }
                    } else {
                        RE_PRODUIT.find(line)?.let { p ->
                            lines += ParsedDriveLine(
                                section = section,
                                label = p.groupValues[1].trim(),
                                quantity = p.groupValues[2].eur(),
                                unitPrice = p.groupValues[3].eur(),
                                total = p.groupValues[4].eur()
                            )
                        }
                    }
                }
            }
        }

        val total = RE_TOTAL.find(text)?.groupValues?.get(1)?.eur()
            ?: throw IllegalArgumentException("Total de la commande introuvable.")

        return ParsedDriveOrder(
            orderId = orderId,
            date = "$y-$m-$d",
            time = "%02d:%s".format(hour.toInt(), minute),
            store = RE_MAGASIN.find(text)?.groupValues?.get(1)?.trim(),
            productCount = count.toInt(),
            total = total,
            savings = RE_ECONOMIES.find(text)?.groupValues?.get(1)?.eur() ?: 0.0,
            ticketLeclerc = RE_TICKET.find(text)?.groupValues?.get(1)?.eur() ?: 0.0,
            lines = lines
        )
    }

    /** Somme des lignes vs total : détecte un changement de format Leclerc. */
    fun isConsistent(order: ParsedDriveOrder): Boolean {
        val sum = order.lines.sumOf { it.total }
        return kotlin.math.abs(sum - order.total) < 0.01
    }
}
