package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ErrorLogScreen(viewModel: BudgetViewModel) {
    val errorLog by viewModel.errorLog.observeAsState(emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(
                "Journal",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { viewModel.clearErrorLog() }) {
                Text("Vider")
            }
        }

        if (errorLog.isEmpty()) {
            Text("Aucun message enregistré.")
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(errorLog) { message ->
                    val textColor = when {
                        "[ERROR]" in message -> Color(0xFFD32F2F)
                        "[WARNING]" in message -> Color(0xFFF57C00)
                        "[DEBUG]" in message -> Color(0xFF455A64)
                        else -> MaterialTheme.colorScheme.onSurface
                    }

                    Text(
                        text = message,
                        color = textColor,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}
