package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun BudgetScreen(viewModel: BudgetViewModel) {
    val budget by viewModel.budgetLiveData.observeAsState()
    val weeklyBudget by viewModel.weeklyBudgetLiveData.observeAsState(0.0)
    val incomes by viewModel.incomesLiveData.observeAsState(emptyList())
    val expensesByCategory by viewModel.expensesByCategory.observeAsState(emptyList())

    LaunchedEffect(Unit) {
        viewModel.refreshBudget()
        viewModel.calculateCurrentWeekBudget()
        viewModel.loadExpensesByCategory()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("💰 Budget Mensuel", fontSize = 22.sp)
            Text("💵 Restant = ${budget?.disposableLeftover ?: 0.0} €", fontSize = 18.sp)
            Text("📅 Budget hebdomadaire restant = $weeklyBudget €", fontSize = 18.sp)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text("💵 Ressources Mensuelles", fontSize = 20.sp)
        }

        if (incomes.isEmpty()) {
            item { Text("Aucune ressource enregistrée") }
        } else {
            items(incomes) { income ->
                ListItem(
                    headlineContent = { Text(income.title) },
                    supportingContent = { Text("${income.amount} €") }
                )
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text("📊 Dépenses par catégorie", fontSize = 20.sp)
        }

        if (expensesByCategory.isEmpty()) {
            item { Text("Aucune dépense enregistrée") }
        } else {
            items(expensesByCategory) {
                ListItem(
                    headlineContent = { Text(it.category) },
                    trailingContent = { Text("${it.total} €") }
                )
            }
        }
    }
}
