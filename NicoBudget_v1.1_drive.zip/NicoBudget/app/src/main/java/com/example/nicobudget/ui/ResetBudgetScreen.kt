package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ResetBudgetScreen(viewModel: BudgetViewModel) {
    var adjustment by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Clôtures", style = MaterialTheme.typography.headlineSmall)

        OutlinedTextField(
            value = adjustment,
            onValueChange = { adjustment = it },
            label = { Text("Décalage éventuel (+ ou -)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                viewModel.resetBudget(adjustment.toDoubleOrNull() ?: 0.0)
                confirmation = "Le budget a été réinitialisé et les dépenses archivées."
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Réinitialiser le budget")
        }

        OutlinedButton(
            onClick = { viewModel.closeCurrentWeek() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Clôturer la semaine")
        }

        confirmation?.let { Text(it) }
    }
}
