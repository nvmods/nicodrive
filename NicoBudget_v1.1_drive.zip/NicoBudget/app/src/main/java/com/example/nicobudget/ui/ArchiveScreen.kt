package com.example.nicobudget.ui

import android.app.DatePickerDialog
import android.content.Context
import android.graphics.Color as AColor
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.data.model.ExpenseArchiveEntity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.time.LocalDate

@Composable
fun ArchiveScreen(viewModel: BudgetViewModel) {
    var archiveList by remember { mutableStateOf(emptyList<ExpenseArchiveEntity>()) }
    var filteredList by remember { mutableStateOf(emptyList<ExpenseArchiveEntity>()) }

    val months = (1..12).map { String.format("%02d", it) }
    var selectedMonth by remember { mutableStateOf<String?>(null) }
    var startDate by remember { mutableStateOf<LocalDate?>(null) }
    var endDate by remember { mutableStateOf<LocalDate?>(null) }
    var expanded by remember { mutableStateOf(false) }

    val context = LocalContext.current

    LaunchedEffect(Unit) {
        archiveList = viewModel.getArchivedExpenses()
        filteredList = archiveList
    }

    fun applyFilter() {
        filteredList = filterExpenses(
            archiveList,
            selectedMonth,
            startDate,
            endDate
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Archives", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))

        Box {
            Button(onClick = { expanded = true }) {
                Text(selectedMonth?.let { "Mois $it" } ?: "Tous les mois")
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Tous les mois") },
                    onClick = {
                        selectedMonth = null
                        expanded = false
                        applyFilter()
                    }
                )
                months.forEach { month ->
                    DropdownMenuItem(
                        text = { Text("Mois $month") },
                        onClick = {
                            selectedMonth = month
                            expanded = false
                            applyFilter()
                        }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    showDatePicker(context) {
                        startDate = it
                        applyFilter()
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Début\n${startDate ?: "--"}")
            }

            Button(
                onClick = {
                    showDatePicker(context) {
                        endDate = it
                        applyFilter()
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Fin\n${endDate ?: "--"}")
            }
        }

        TextButton(
            onClick = {
                selectedMonth = null
                startDate = null
                endDate = null
                filteredList = archiveList
            }
        ) {
            Text("Réinitialiser les filtres")
        }

        BarChartView(filteredList)

        Text(
            "Total filtré : ${filteredList.sumOf { it.amount }} €",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filteredList, key = { it.id }) { expense ->
                ListItem(
                    headlineContent = {
                        Text("${expense.category} - ${expense.amount} €")
                    },
                    supportingContent = {
                        Text("Dépense : ${expense.date} · Archivage : ${expense.archivedAt}")
                    }
                )
                HorizontalDivider()
            }
        }
    }
}

fun filterExpenses(
    list: List<ExpenseArchiveEntity>,
    selectedMonth: String?,
    startDate: LocalDate?,
    endDate: LocalDate?
): List<ExpenseArchiveEntity> {
    return list.filter { expense ->
        try {
            val date = LocalDate.parse(expense.date)
            val matchMonth =
                selectedMonth?.let { date.monthValue == it.toInt() } ?: true
            val matchStart = startDate?.let { !date.isBefore(it) } ?: true
            val matchEnd = endDate?.let { !date.isAfter(it) } ?: true
            matchMonth && matchStart && matchEnd
        } catch (_: Exception) {
            false
        }
    }
}

@Composable
fun BarChartView(expenses: List<ExpenseArchiveEntity>) {
    val grouped = expenses.groupBy { it.category }
    val entries = grouped.entries.mapIndexed { index, entry ->
        BarEntry(index.toFloat(), entry.value.sumOf { it.amount }.toFloat())
    }
    val labels = grouped.keys.toList()

    AndroidView(
        modifier = Modifier
            .fillMaxWidth()
            .height(250.dp),
        factory = { context ->
            BarChart(context).apply {
                axisRight.isEnabled = false
                description.isEnabled = false
                legend.isEnabled = false
                xAxis.position = XAxis.XAxisPosition.BOTTOM
                xAxis.granularity = 1f
                xAxis.setDrawGridLines(false)
            }
        },
        update = { chart ->
            val dataSet = BarDataSet(entries, "Dépenses par catégorie").apply {
                color = AColor.rgb(0, 172, 193)
                valueTextColor = AColor.BLACK
                valueTextSize = 12f
            }

            chart.data = BarData(dataSet)
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            chart.notifyDataSetChanged()
            chart.invalidate()
        }
    )
}

fun showDatePicker(
    context: Context,
    onDateSelected: (LocalDate) -> Unit
) {
    val now = LocalDate.now()
    DatePickerDialog(
        context,
        { _, year, month, day ->
            onDateSelected(LocalDate.of(year, month + 1, day))
        },
        now.year,
        now.monthValue - 1,
        now.dayOfMonth
    ).show()
}
