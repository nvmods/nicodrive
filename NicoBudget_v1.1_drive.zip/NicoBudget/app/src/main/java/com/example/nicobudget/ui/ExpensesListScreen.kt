package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ExpensesListScreen(
    viewModel: BudgetViewModel,
    onBack: () -> Unit
) {
    val expenses by viewModel.allExpensesLiveData.observeAsState(emptyList())

    Column(modifier = Modifier.fillMaxSize()) {
        OutlinedButton(
            onClick = onBack,
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Retour")
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(expenses, key = { it.id }) { expense ->
                ListItem(
                    headlineContent = { Text("${expense.category} - ${expense.amount} €") },
                    supportingContent = { Text(expense.date) },
                    trailingContent = {
                        TextButton(onClick = { viewModel.deleteExpense(expense) }) {
                            Text("Supprimer")
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
