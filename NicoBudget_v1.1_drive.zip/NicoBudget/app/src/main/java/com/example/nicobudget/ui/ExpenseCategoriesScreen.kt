package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ExpenseCategoriesScreen(viewModel: BudgetViewModel) {
    val categories by viewModel.expenseCategoriesLiveData.observeAsState(emptyList())
    var name by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nouvelle catégorie") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addCategory(name)
                        name = ""
                    }
                }
            ) {
                Text("Ajouter")
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(categories, key = { it.id }) { category ->
                ListItem(
                    headlineContent = { Text(category.name) },
                    trailingContent = {
                        TextButton(onClick = { viewModel.deleteCategory(category) }) {
                            Text("Supprimer")
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
