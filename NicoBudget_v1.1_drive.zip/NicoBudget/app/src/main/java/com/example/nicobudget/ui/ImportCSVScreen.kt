package com.example.nicobudget.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ImportCSVScreen(viewModel: BudgetViewModel) {
    val context = LocalContext.current
    var importStatus by remember { mutableStateOf<String?>(null) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var importing by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        selectedUri = uri

        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Certains fournisseurs ne donnent qu'une permission temporaire.
            }

            importing = true
            importStatus = "Import en cours…"
            viewModel.importFromCsv(uri, context) { result ->
                importStatus = result
                importing = false
            }
        } else {
            importStatus = "Aucun fichier sélectionné."
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            "Importer les données CSV",
            style = MaterialTheme.typography.headlineSmall
        )

        Text(
            "Colonnes attendues : type,date,libelle,montant,categorie\n" +
                "Séparateur ',' ou ';' (utiliser ';' si les montants " +
                "contiennent une virgule)."
        )

        Button(
            onClick = {
                launcher.launch(
                    arrayOf(
                        "text/csv",
                        "text/comma-separated-values",
                        "application/csv",
                        "text/plain",
                        "application/vnd.ms-excel"
                    )
                )
            },
            enabled = !importing,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Sélectionner un fichier CSV")
        }

        selectedUri?.let {
            Text("Fichier sélectionné : ${it.lastPathSegment ?: it}")
        }

        importStatus?.let {
            Text(it, color = MaterialTheme.colorScheme.primary)
        }
    }
}
