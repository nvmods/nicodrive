package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.util.customButtonColorsBleu
import com.example.nicobudget.util.customButtonColorsRouge
import com.example.nicobudget.util.customButtonColorsVert

@Composable
fun SettingsScreen(viewModel: BudgetViewModel) {
    val incomes by viewModel.incomesLiveData.observeAsState(emptyList())
    val fixedCharges by viewModel.fixedChargesLiveData.observeAsState(emptyList())

    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var chargeName by remember { mutableStateOf("") }
    var chargeAmount by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("➕ Ajouter un revenu", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Titre du revenu") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Montant (€)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    amount.toDoubleOrNull()?.let {
                        if (title.isNotBlank()) {
                            viewModel.addIncome(title, it)
                            title = ""
                            amount = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = customButtonColorsBleu()
            ) {
                Text("Ajouter le revenu")
            }
        }

        item {
            HorizontalDivider()
            Text("➕ Ajouter une charge", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(
                value = chargeName,
                onValueChange = { chargeName = it },
                label = { Text("Nom de la charge") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = chargeAmount,
                onValueChange = { chargeAmount = it },
                label = { Text("Montant (€)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Button(
                onClick = {
                    chargeAmount.toDoubleOrNull()?.let {
                        if (chargeName.isNotBlank()) {
                            viewModel.addFixedCharge(chargeName, it)
                            chargeName = ""
                            chargeAmount = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = customButtonColorsBleu()
            ) {
                Text("Ajouter la charge")
            }
        }

        item {
            HorizontalDivider()
            Text("📋 Revenus", style = MaterialTheme.typography.titleLarge)
        }

        items(incomes, key = { it.id }) { income ->
            var showDeleteDialog by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(income.title)
                    Text("${income.amount} €")
                }
                Button(
                    onClick = { showDeleteDialog = true },
                    colors = customButtonColorsRouge()
                ) {
                    Text("Supprimer")
                }
            }

            if (showDeleteDialog) {
                AlertDialog(
                    onDismissRequest = { showDeleteDialog = false },
                    title = { Text("Confirmation") },
                    text = { Text("Supprimer ce revenu ?") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.deleteIncome(income)
                                showDeleteDialog = false
                            },
                            colors = customButtonColorsVert()
                        ) {
                            Text("Oui")
                        }
                    },
                    dismissButton = {
                        Button(
                            onClick = { showDeleteDialog = false },
                            colors = customButtonColorsRouge()
                        ) {
                            Text("Annuler")
                        }
                    }
                )
            }
        }

        item {
            HorizontalDivider()
            Text("📋 Charges fixes", style = MaterialTheme.typography.titleLarge)
        }

        items(fixedCharges, key = { it.id }) { charge ->
            var showDeleteDialogCharge by remember { mutableStateOf(false) }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(charge.name)
                    Text("${charge.amount} €")
                }
                Button(
                    onClick = { showDeleteDialogCharge = true },
                    colors = customButtonColorsRouge()
                ) {
                    Text("Supprimer")
                }
            }

            if (showDeleteDialogCharge) {
                AlertDialog(
                    onDismissRequest = { showDeleteDialogCharge = false },
                    title = { Text("Confirmation") },
                    text = { Text("Supprimer cette charge ?") },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.deleteFixedCharge(charge)
                                showDeleteDialogCharge = false
                            },
                            colors = customButtonColorsVert()
                        ) {
                            Text("Oui")
                        }
                    },
                    dismissButton = {
                        Button(
                            onClick = { showDeleteDialogCharge = false },
                            colors = customButtonColorsRouge()
                        ) {
                            Text("Annuler")
                        }
                    }
                )
            }
        }
    }
}
