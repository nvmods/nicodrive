package com.example.nicobudget.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.nicobudget.data.model.*

@Dao
interface FixedChargeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharge(charge: FixedChargeEntity)

    @Delete
    suspend fun deleteCharge(charge: FixedChargeEntity)

    @Query("SELECT * FROM fixed_charges ORDER BY id DESC")
    fun getAllFixedCharges(): LiveData<List<FixedChargeEntity>>

    @Query("SELECT * FROM fixed_charges ORDER BY id DESC")
    suspend fun getAllFixedChargesNow(): List<FixedChargeEntity>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM fixed_charges")
    suspend fun getTotalFixedCharges(): Double?
}

@Dao
interface FixedIncomeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncome(income: FixedIncomeEntity)

    @Delete
    suspend fun deleteIncome(income: FixedIncomeEntity)

    @Query("SELECT * FROM fixed_incomes ORDER BY id DESC")
    fun getAllIncomes(): LiveData<List<FixedIncomeEntity>>

    @Query("SELECT * FROM fixed_incomes ORDER BY id DESC")
    suspend fun getAllIncomesNow(): List<FixedIncomeEntity>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM fixed_incomes")
    suspend fun getTotalIncome(): Double?
}

@Dao
interface ExpenseDao {
    @Insert
    suspend fun insertExpense(expense: ExpenseEntity): Long

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity): Int

    @Query("SELECT * FROM expenses ORDER BY id DESC")
    fun getAllExpenses(): LiveData<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY id DESC")
    suspend fun getAllExpensesNow(): List<ExpenseEntity>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE date LIKE :monthYear || '%'")
    suspend fun getExpensesForMonth(monthYear: String): Double

    @Query("SELECT category, SUM(amount * 1.0) as total FROM expenses GROUP BY category")
    suspend fun getTotalExpensesByCategory(): List<CategoryExpenseTotal>

    @Query("SELECT category, SUM(amount * 1.0) as total FROM expenses GROUP BY category")
    fun getTotalExpensesByCategoryNow(): List<CategoryExpenseTotal>

    @Query("DELETE FROM expenses")
    suspend fun deleteAllExpenses()
}

@Dao
interface ExpenseCategoryDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCategory(category: ExpenseCategoryEntity)

    @Delete
    suspend fun deleteCategory(category: ExpenseCategoryEntity)

    @Query("SELECT * FROM expense_categories ORDER BY name")
    fun getAllCategories(): LiveData<List<ExpenseCategoryEntity>>
}

@Dao
interface MonthlyBudgetDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudget(budget: MonthlyBudgetEntity)

    @Query("SELECT * FROM monthly_budget ORDER BY revenueId DESC LIMIT 1")
    fun getLatestBudget(): LiveData<MonthlyBudgetEntity?>

    @Delete
    suspend fun deleteBudget(budget: MonthlyBudgetEntity)

    @Query("SELECT * FROM monthly_budget ORDER BY revenueId DESC")
    fun getAllBudgets(): LiveData<List<MonthlyBudgetEntity>>

    @Query("SELECT * FROM monthly_budget ORDER BY monthYear DESC LIMIT 1")
    suspend fun getBudgetById(): MonthlyBudgetEntity?

    @Query("SELECT * FROM monthly_budget WHERE monthYear = :monthYear LIMIT 1")
    suspend fun getBudgetBlocking(monthYear: String): MonthlyBudgetEntity?

    @Query("""
        UPDATE monthly_budget
        SET disposableLeftover = (
            COALESCE((SELECT SUM(amount) FROM fixed_incomes), 0)
            - COALESCE((SELECT SUM(amount) FROM fixed_charges), 0)
            - COALESCE((SELECT SUM(amount) FROM expenses), 0)
        )
        WHERE revenueId = (
            SELECT revenueId FROM monthly_budget
            ORDER BY startDate DESC LIMIT 1
        )
    """)
    suspend fun updateDisposableLeftover()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertArchivedExpense(expense: ExpenseArchiveEntity)

    @Query("SELECT * FROM expense_archive ORDER BY archivedAt DESC, id DESC")
    suspend fun getAllArchivedExpenses(): List<ExpenseArchiveEntity>
}
