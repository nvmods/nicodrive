package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel

@Composable
fun ExpensesScreen(
    viewModel: BudgetViewModel,
    onNavigateToList: () -> Unit
) {
    val categories by viewModel.expenseCategoriesLiveData.observeAsState(emptyList())
    var category by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ajouter une dépense", style = MaterialTheme.typography.titleLarge)

        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(category.ifBlank { "Choisir une catégorie" })
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                categories.forEach {
                    DropdownMenuItem(
                        text = { Text(it.name) },
                        onClick = {
                            category = it.name
                            expanded = false
                        }
                    )
                }
            }
        }

        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Montant (€)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                amount.toDoubleOrNull()?.let {
                    if (category.isNotBlank()) {
                        viewModel.addExpense(category, it)
                        amount = ""
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Ajouter")
        }

        OutlinedButton(
            onClick = onNavigateToList,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Voir la liste des dépenses")
        }
    }
}
