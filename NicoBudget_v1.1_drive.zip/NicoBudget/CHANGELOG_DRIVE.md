# NicoBudget 1.1 — Intégration Leclerc Drive

## Nouveautés

### Écran "Leclerc Drive" (menu latéral)
- Import d'un ou plusieurs bons de commande PDF via le sélecteur de fichiers.
- **Partage direct** : depuis Gmail (ou Fichiers), ouvrir le PDF du bon de
  commande et le partager vers NicoBudget — l'app s'ouvre sur l'écran Drive
  et importe automatiquement. Workflow après chaque commande : mail Leclerc
  -> lien "bon de commande" -> le PDF se télécharge -> Partager -> NicoBudget.
- Historique des commandes, dépliables pour voir les lignes (produit,
  quantité, prix), avec économies anti-gaspi et gains Ticket E.Leclerc.
- Totaux par mois et **recherche produit** ("eau" -> quantités et dépense
  par mois).
- Suppression d'une commande (avec sa dépense budget liée) après confirmation.

### Intégration au budget
Chaque commande importée crée une dépense dans la catégorie "Courses Drive"
(créée automatiquement) : le restant disponible et le budget hebdo la
prennent en compte immédiatement. L'import est idempotent (n° de commande
unique) : réimporter le même PDF ne double pas la dépense.

### Technique
- Nouvelles tables Room `drive_orders` et `drive_order_lines`
  (migration 10 -> 11 incluse, FK ON DELETE CASCADE).
- Parser PDF : PdfBox-Android (`com.tom-roush:pdfbox-android:2.0.27.0`).
  Logique de parsing validée sur bon de commande réel (format 2026) :
  n° commande, date/heure, magasin, rayons Leclerc, quantités décimales
  (produits au poids), total, économies, tickets. Contrôle de cohérence
  somme des lignes vs total (warning dans l'Error Log si écart —
  indicateur d'un changement de format Leclerc).
- Manifest : intent-filters ACTION_SEND / ACTION_VIEW sur application/pdf,
  launchMode singleTask pour router les partages vers l'instance existante.

## Corrections

### Import CSV (bug réel corrigé)
- La lecture du fichier et les insertions se faisaient sur le main thread
  (via un appel direct depuis l'écran) et les insertions étaient lancées
  dans des coroutines "fire and forget" : le compte rendu pouvait précéder
  les insertions et `updateDisposableLeftover()` pouvait s'exécuter avant
  elles. Désormais : tout tourne sur Dispatchers.IO, insertions
  séquentielles, résultat renvoyé par callback, indicateur "Import en
  cours…" dans l'écran.
- Un montant français "12,50" cassait le découpage `split(",")` (colonnes
  décalées). Le séparateur ';' est maintenant accepté (détection
  automatique par ligne).

### Divers
- Résumé exporté par e-mail : ajoute une section Leclerc Drive du mois
  (nb de commandes, total, économies) si des commandes existent.

## Points de vigilance
- Testé sur le format de bon de commande 2026 à quantités entières ;
  les quantités décimales (produits au poids) sont gérées par la regex
  mais restent à valider sur un PDF réel de ce type.
- Si Leclerc change la mise en page du PDF, l'import échouera proprement
  ("Ce PDF ne ressemble pas à un bon de commande") ou lèvera un warning
  de cohérence dans l'Error Log.

## Audit de conformité au descriptif (Principes de fonctionnement)

Conforme : §1-5, §7-12, principes de développement (pas de renommage,
logique centralisée dans BudgetViewModel, valeurs lues depuis la base).

Deux écarts corrigés :
1. §6 (cycle 27 -> 27) : le budget créé au reset stockait
   startDate = "AAAA-MM-01" et endDate = "AAAA-MM-28" (mois calendaire).
   Il stocke désormais les vraies bornes du cycle (27 du mois courant ou
   précédent -> 27 suivant). Note : monthYear reste le mois calendaire du
   reset, utilisé comme clé de recherche — inchangé volontairement.
2. §10 (journal) : logError() faisait un read-modify-write sur la
   LiveData depuis des threads IO ; des messages rapprochés pouvaient se
   perdre (coalescence de postValue). Un buffer synchronisé garantit
   maintenant qu'aucun message n'est perdu.
