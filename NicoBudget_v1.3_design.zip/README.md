# NicoBudget 1.2 — budget personnel + Leclerc Drive

Application Android (Kotlin / Compose / Room) de gestion de budget avec
intégration Leclerc Drive : les bons de commande sont récupérés depuis les
mails (IMAP SFR), parsés (PDF) et injectés comme dépenses dans le budget.

## Nouveautés 1.2
- **Synchro automatique** : worker en arrière-plan toutes les 6 h (activable
  dans l'écran Drive, nécessite la config mail). L'idempotence sur le n° de
  commande évite tout doublon.
- **Design revu** : thème Material 3 complet (palette "encre & menthe"),
  mode sombre automatique, cartes élevées, top bar aux couleurs du thème.
- **Code consolidé** : toutes les corrections du cycle de debug intégrées
  aux sources (JVM 17, Room 2.7.1, parser PDF tolérant, contournement 403
  Leclerc par cookies+Referer, packaging Jakarta Mail). Le workflow CI ne
  contient plus aucun patch : il ne fait que versionner et builder.
- Import Drive factorisé dans `drive/DriveImporter` (partagé ViewModel /
  worker), catégorie "Courses Drive" dédupliquée.

## Build
GitHub Actions : push sur `main` → APK dans l'onglet Actions (artifact
`NicoBudget-debug-apk`). `versionName` = `1.2-b<numéro de run>` pour
vérifier la version installée dans les paramètres Android.

Local : Android Studio, `assembleDebug` (JDK 17).

## Écrans
Budget (restant, hebdo), Dépenses, Leclerc Drive (synchro mail, import PDF,
stats par mois et par produit), Ressources/charges, Clôtures, Catégories,
Import CSV, Export résumé, Archives, Error Log.

## 1.3 — refonte visuelle globale
Tous les écrans repensés : kit de composants partagés (`ui/components/UiKit.kt`
— SectionCard, AmountRow, ConfirmDialog, formatage monétaire uniforme),
carte héro du budget avec progression de semaine, barres de proportion par
catégorie, icônes vectorielles à la place des emojis, confirmations de
suppression partout, montants formatés "1 234,56 €".
