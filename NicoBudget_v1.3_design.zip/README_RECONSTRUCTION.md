# NicoBudget — reconstruction depuis la conversation

Ce projet a été reconstitué à partir des extraits de code et des journaux présents
dans la conversation. Il ne s'agit pas d'une copie bit-à-bit du projet perdu.

## Éléments reconstruits

- Budget mensuel et budget hebdomadaire
- Revenus et charges fixes sans notion de mois
- Dépenses et catégories
- Réinitialisation manuelle du budget
- Clôture de semaine le vendredi
- Archivage des dépenses pendant le reset
- Écran d'archives avec filtres et graphique
- Import CSV
- Résumé envoyé par e-mail
- Journal de messages DEBUG / WARNING / ERROR
- Migration Room 9 vers 10 pour `expense_archive`

## Format CSV

```csv
type,date,libelle,montant,categorie
ressource,2025-03-01,Salaire,2500,revenu
charge,2025-03-01,Loyer,750,logement
operation,2025-03-02,Supermarché,120,alimentation
```

## Points à vérifier

1. Les anciennes migrations Room 1 à 9 ne figuraient pas entièrement dans la conversation.
   La reconstruction contient uniquement la migration 9 vers 10.
2. Si l'appareil possède une base plus ancienne et qu'une migration intermédiaire manque,
   désinstaller l'application de test ou recréer les migrations nécessaires.
3. L'adresse e-mail par défaut est `destinataire@example.com`.
4. MPAndroidChart est récupéré via JitPack.
5. Les versions Gradle/Compose ont été choisies pour produire un projet moderne cohérent,
   mais peuvent nécessiter un ajustement selon la version d'Android Studio installée.
