package com.example.nicobudget

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Input
import androidx.compose.material.icons.automirrored.filled.LabelImportant
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.ui.*
import com.example.nicobudget.ui.theme.NicoBudgetTheme
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    private val viewModel: BudgetViewModel by viewModels()

    /** PDF reçu via un partage (Gmail / Fichiers -> NicoBudget). */
    private var sharedPdfUri by mutableStateOf<Uri?>(null)

    private fun extractPdfUri(intent: Intent?): Uri? = when (intent?.action) {
        Intent.ACTION_SEND ->
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        Intent.ACTION_VIEW -> intent.data
        else -> null
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        extractPdfUri(intent)?.let { sharedPdfUri = it }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        extractPdfUri(intent)?.let { sharedPdfUri = it }

        // Replanifie la synchro Drive en arrière-plan si elle est activée.
        if (com.example.nicobudget.drive.DriveMailSync.isAutoSync(this)) {
            com.example.nicobudget.drive.DriveSyncWorker.schedule(this)
        }

        setContent {
            NicoBudgetTheme {
                val navController = rememberNavController()
                val drawerState = rememberDrawerState(DrawerValue.Closed)
                val scope = rememberCoroutineScope()

                // Un PDF partagé ouvre directement l'écran Drive.
                LaunchedEffect(sharedPdfUri) {
                    if (sharedPdfUri != null) {
                        navController.navigate("drive") { launchSingleTop = true }
                    }
                }

                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(modifier = Modifier.fillMaxHeight()) {
                            Spacer(modifier = Modifier.height(24.dp))

                            DrawerItem(Icons.Default.AttachMoney, "Budget") {
                                navController.navigate("budget") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.AutoMirrored.Filled.ReceiptLong, "Dépenses") {
                                navController.navigate("expenses") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.AutoMirrored.Filled.List, "Liste des Dépenses") {
                                navController.navigate("expensesList") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.ShoppingCart, "Leclerc Drive") {
                                navController.navigate("drive") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.AutoMirrored.Filled.Input, "Ressources et charges") {
                                navController.navigate("settings") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.AutoMirrored.Filled.LabelImportant, "Clôtures") {
                                navController.navigate("resetbudget") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.Category, "Catégories dépenses") {
                                navController.navigate("expensesCategory") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.FileOpen, "Import CSV") {
                                navController.navigate("importcsv") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.Send, "Exporter résumé") {
                                navController.navigate("exportsummary") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.History, "Archives") {
                                navController.navigate("archives") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.Default.Error, "Error Log") {
                                navController.navigate("errorlog") { launchSingleTop = true }
                                scope.launch { drawerState.close() }
                            }
                            DrawerItem(Icons.AutoMirrored.Filled.ExitToApp, "Quitter") {
                                finishAffinity()
                                exitProcess(0)
                            }
                        }
                    }
                ) {
                    Scaffold(
                        topBar = {
                            CenterAlignedTopAppBar(
                                title = {
                                    Text(
                                        text = "NicoBudget",
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                },
                                navigationIcon = {
                                    IconButton(
                                        onClick = { scope.launch { drawerState.open() } }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Menu,
                                            contentDescription = "Menu",
                                            tint = MaterialTheme.colorScheme.onPrimary
                                        )
                                    }
                                },
                                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    ) { innerPadding ->
                        Surface(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            NavHost(navController, startDestination = "budget") {
                                composable("budget") { BudgetScreen(viewModel) }
                                composable("settings") { SettingsScreen(viewModel) }
                                composable("resetbudget") { ResetBudgetScreen(viewModel) }
                                composable("expenses") {
                                    ExpensesScreen(
                                        viewModel,
                                        onNavigateToList = {
                                            navController.navigate("expensesList")
                                        }
                                    )
                                }
                                composable("expensesList") {
                                    ExpensesListScreen(
                                        viewModel,
                                        onBack = { navController.popBackStack() }
                                    )
                                }
                                composable("expensesCategory") {
                                    ExpenseCategoriesScreen(viewModel)
                                }
                                composable("importcsv") { ImportCSVScreen(viewModel) }
                                composable("exportsummary") { ExportSummaryScreen(viewModel) }
                                composable("archives") { ArchiveScreen(viewModel) }
                                composable("errorlog") { ErrorLogScreen(viewModel) }
                                composable("drive") {
                                    DriveScreen(
                                        viewModel,
                                        pendingPdfUri = sharedPdfUri,
                                        onPendingConsumed = { sharedPdfUri = null }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DrawerItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    text: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp, horizontal = 16.dp)
    ) {
        Icon(icon, contentDescription = text, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(12.dp))
        Text(text, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}
