package com.example.nicobudget.drive

import android.content.Context
import androidx.core.net.toUri
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Synchro automatique des commandes Drive en arrière-plan.
 * Toutes les 6 heures (si réseau dispo) : lecture des mails Leclerc,
 * téléchargement des bons de commande, import en base. L'idempotence de
 * DriveImporter fait le tri des commandes déjà connues.
 */
class DriveSyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val context = applicationContext
        if (!DriveMailSync.isAutoSync(context)) return@withContext Result.success()
        val config = DriveMailSync.loadConfig(context)
            ?: return@withContext Result.success()

        try {
            val report = DriveMailSync.sync(context, config)
            report.pdfs.forEach { file ->
                DriveImporter.import(context, file.toUri())
                file.delete()
            }
            Result.success()
        } catch (e: Exception) {
            // Réseau indisponible, IMAP en rade... on retentera au prochain cycle.
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "drive_mail_sync"

        /** À appeler au démarrage de l'app : planifie (ou re-planifie) la synchro. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<DriveSyncWorker>(6, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
