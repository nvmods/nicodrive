package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.ui.components.*

@Composable
fun BudgetScreen(viewModel: BudgetViewModel) {
    val budget by viewModel.budgetLiveData.observeAsState()
    val weeklyBudget by viewModel.weeklyBudgetLiveData.observeAsState(0.0)
    val incomes by viewModel.incomesLiveData.observeAsState(emptyList())
    val expensesByCategory by viewModel.expensesByCategory.observeAsState(emptyList())

    LaunchedEffect(Unit) {
        viewModel.refreshBudget()
        viewModel.calculateCurrentWeekBudget()
        viewModel.loadExpensesByCategory()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // ---------- Carte principale : restant disponible ----------
        item {
            Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        "Restant disponible",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                    )
                    Text(
                        (budget?.disposableLeftover ?: 0.0).eur(),
                        style = MaterialTheme.typography.displaySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "Budget de la semaine",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                            )
                            Text(
                                weeklyBudget.eur(),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        budget?.let { b ->
                            Surface(
                                shape = MaterialTheme.shapes.small,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    "Semaine ${b.currentWeekIndex}/${b.totalWeeks}",
                                    modifier = Modifier.padding(
                                        horizontal = 10.dp, vertical = 6.dp
                                    ),
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                    budget?.let { b ->
                        if (b.totalWeeks > 0) {
                            Spacer(Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = {
                                    b.currentWeekIndex.toFloat() / b.totalWeeks
                                },
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.secondary,
                                trackColor = MaterialTheme.colorScheme.onPrimary
                                    .copy(alpha = 0.2f)
                            )
                        }
                    }
                }
            }
        }

        // ---------- Ressources ----------
        item {
            SectionCard(Icons.AutoMirrored.Filled.TrendingUp, "Ressources mensuelles") {
                if (incomes.isEmpty()) {
                    EmptyHint(
                        "Aucune ressource. Ajoute tes revenus dans " +
                            "« Ressources et charges »."
                    )
                } else {
                    incomes.forEach { income ->
                        AmountRow(income.title, income.amount)
                    }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    AmountRow(
                        "Total",
                        incomes.sumOf { it.amount },
                        emphasized = true
                    )
                }
            }
        }

        // ---------- Dépenses par catégorie ----------
        item {
            SectionCard(Icons.Default.Category, "Dépenses par catégorie") {
                if (expensesByCategory.isEmpty()) {
                    EmptyHint("Aucune dépense sur ce cycle.")
                } else {
                    val maxTotal = expensesByCategory.maxOf { it.total }
                    expensesByCategory.forEach { cat ->
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    cat.category,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    cat.total.eur(),
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Spacer(Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = {
                                    if (maxTotal > 0)
                                        (cat.total / maxTotal).toFloat()
                                    else 0f
                                },
                                modifier = Modifier.fillMaxWidth(),
                                color = MaterialTheme.colorScheme.tertiary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 6.dp))
                    AmountRow(
                        "Total dépensé",
                        expensesByCategory.sumOf { it.total },
                        emphasized = true
                    )
                }
            }
        }

        item {
            SectionCard(Icons.Default.Payments, "Revenus mensuels du budget") {
                AmountRow(
                    "Revenu pris en compte au dernier reset",
                    budget?.monthlyIncome ?: 0.0
                )
            }
        }
    }
}
