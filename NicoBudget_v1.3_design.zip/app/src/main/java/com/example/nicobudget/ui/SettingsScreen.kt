package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.data.model.FixedChargeEntity
import com.example.nicobudget.data.model.FixedIncomeEntity
import com.example.nicobudget.ui.components.*

@Composable
fun SettingsScreen(viewModel: BudgetViewModel) {
    val incomes by viewModel.incomesLiveData.observeAsState(emptyList())
    val fixedCharges by viewModel.fixedChargesLiveData.observeAsState(emptyList())

    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var chargeName by remember { mutableStateOf("") }
    var chargeAmount by remember { mutableStateOf("") }
    var incomeToDelete by remember { mutableStateOf<FixedIncomeEntity?>(null) }
    var chargeToDelete by remember { mutableStateOf<FixedChargeEntity?>(null) }

    incomeToDelete?.let { income ->
        ConfirmDialog(
            title = "Supprimer ce revenu ?",
            text = "${income.title} — ${income.amount.eur()}",
            confirmLabel = "Supprimer",
            onConfirm = {
                viewModel.deleteIncome(income)
                incomeToDelete = null
            },
            onDismiss = { incomeToDelete = null }
        )
    }
    chargeToDelete?.let { charge ->
        ConfirmDialog(
            title = "Supprimer cette charge ?",
            text = "${charge.name} — ${charge.amount.eur()}",
            confirmLabel = "Supprimer",
            onConfirm = {
                viewModel.deleteFixedCharge(charge)
                chargeToDelete = null
            },
            onDismiss = { chargeToDelete = null }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // ---------------- Revenus ----------------
        item {
            SectionCard(
                Icons.AutoMirrored.Filled.TrendingUp,
                "Revenus",
                trailing = {
                    Text(
                        incomes.sumOf { it.amount }.eur(),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            ) {
                if (incomes.isEmpty()) {
                    EmptyHint("Aucun revenu enregistré.")
                } else {
                    incomes.forEach { income ->
                        AmountRow(
                            income.title,
                            income.amount,
                            trailing = {
                                IconButton(onClick = { incomeToDelete = income }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Supprimer",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Titre du revenu") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("Montant") },
                        suffix = { Text("€") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = {
                            amount.replace(',', '.').toDoubleOrNull()?.let {
                                if (title.isNotBlank()) {
                                    viewModel.addIncome(title, it)
                                    title = ""
                                    amount = ""
                                }
                            }
                        },
                        enabled = title.isNotBlank() &&
                            amount.replace(',', '.').toDoubleOrNull() != null
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Ajouter le revenu")
                    }
                }
            }
        }

        // ---------------- Charges fixes ----------------
        item {
            SectionCard(
                Icons.AutoMirrored.Filled.TrendingDown,
                "Charges fixes",
                trailing = {
                    Text(
                        fixedCharges.sumOf { it.amount }.eur(),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            ) {
                if (fixedCharges.isEmpty()) {
                    EmptyHint("Aucune charge enregistrée.")
                } else {
                    fixedCharges.forEach { charge ->
                        AmountRow(
                            charge.name,
                            charge.amount,
                            trailing = {
                                IconButton(onClick = { chargeToDelete = charge }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Supprimer",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                OutlinedTextField(
                    value = chargeName,
                    onValueChange = { chargeName = it },
                    label = { Text("Nom de la charge") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = chargeAmount,
                        onValueChange = { chargeAmount = it },
                        label = { Text("Montant") },
                        suffix = { Text("€") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Decimal
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    FilledIconButton(
                        onClick = {
                            chargeAmount.replace(',', '.').toDoubleOrNull()?.let {
                                if (chargeName.isNotBlank()) {
                                    viewModel.addFixedCharge(chargeName, it)
                                    chargeName = ""
                                    chargeAmount = ""
                                }
                            }
                        },
                        enabled = chargeName.isNotBlank() &&
                            chargeAmount.replace(',', '.').toDoubleOrNull() != null
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Ajouter la charge")
                    }
                }
            }
        }

        // ---------------- Solde théorique ----------------
        item {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    AmountRow(
                        "Solde théorique (revenus − charges)",
                        incomes.sumOf { it.amount } - fixedCharges.sumOf { it.amount },
                        subtitle = "Appliqué au prochain reset de budget",
                        emphasized = true
                    )
                }
            }
        }
    }
}
