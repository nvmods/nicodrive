package com.example.nicobudget.drive

import android.content.Context
import android.net.Uri
import com.example.nicobudget.data.db.AppDatabase
import com.example.nicobudget.data.model.DriveOrderEntity
import com.example.nicobudget.data.model.DriveOrderLineEntity
import com.example.nicobudget.data.model.ExpenseCategoryEntity
import com.example.nicobudget.data.model.ExpenseEntity

/**
 * Import d'un bon de commande Leclerc Drive dans la base : commande, lignes,
 * et dépense budget liée. Utilisé par le ViewModel (import manuel / synchro
 * à la demande) et par le worker de synchro automatique.
 * Idempotent : une commande déjà en base est refusée proprement.
 */
object DriveImporter {

    const val DRIVE_CATEGORY = "Courses Drive"

    sealed class Result(val message: String) {
        class Imported(message: String, val orderId: String) : Result(message)
        class Duplicate(val orderId: String) :
            Result("Commande n°$orderId déjà importée.")
        class Failed(message: String) : Result(message)
    }

    suspend fun import(context: Context, uri: Uri): Result {
        return try {
            val parsed = LeclercPdfParser.parse(context, uri)
            val db = AppDatabase.getDatabase(context)

            if (db.driveOrderDao().findByOrderId(parsed.orderId) != null) {
                return Result.Duplicate(parsed.orderId)
            }

            if (db.expenseCategoryDao().findByName(DRIVE_CATEGORY) == null) {
                db.expenseCategoryDao().insertCategory(
                    ExpenseCategoryEntity(name = DRIVE_CATEGORY)
                )
            }
            val expenseId = db.expenseDao().insertExpense(
                ExpenseEntity(
                    date = parsed.date,
                    category = DRIVE_CATEGORY,
                    amount = parsed.total
                )
            )
            val orderRowId = db.driveOrderDao().insertOrder(
                DriveOrderEntity(
                    orderId = parsed.orderId,
                    date = parsed.date,
                    time = parsed.time,
                    store = parsed.store,
                    productCount = parsed.productCount,
                    total = parsed.total,
                    savings = parsed.savings,
                    ticketLeclerc = parsed.ticketLeclerc,
                    expenseId = expenseId
                )
            )
            db.driveOrderDao().insertLines(
                parsed.lines.map {
                    DriveOrderLineEntity(
                        orderId = orderRowId.toInt(),
                        section = it.section,
                        label = it.label,
                        quantity = it.quantity,
                        unitPrice = it.unitPrice,
                        total = it.total
                    )
                }
            )
            // Recalcul du restant disponible (même circuit que toute dépense).
            db.monthlyBudgetDao().updateDisposableLeftover()

            Result.Imported(
                "Commande n°${parsed.orderId} du ${parsed.date} importée : " +
                    "%.2f € (%d produits).".format(parsed.total, parsed.productCount),
                parsed.orderId
            )
        } catch (e: Exception) {
            Result.Failed("Erreur : ${e.message}")
        }
    }
}
