package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EventRepeat
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.ui.components.ConfirmDialog
import com.example.nicobudget.ui.components.SectionCard

@Composable
fun ResetBudgetScreen(viewModel: BudgetViewModel) {
    val budget by viewModel.budgetLiveData.observeAsState()
    var adjustment by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf<String?>(null) }
    var showResetConfirm by remember { mutableStateOf(false) }

    if (showResetConfirm) {
        ConfirmDialog(
            title = "Réinitialiser le budget ?",
            text = "Les dépenses du cycle seront archivées, puis un nouveau " +
                "cycle démarrera avec les revenus et charges actuels" +
                (adjustment.replace(',', '.').toDoubleOrNull()
                    ?.takeIf { it != 0.0 }
                    ?.let { " (ajustement de %.2f €)".format(it) } ?: "") + ".",
            confirmLabel = "Réinitialiser",
            onConfirm = {
                viewModel.resetBudget(
                    adjustment.replace(',', '.').toDoubleOrNull() ?: 0.0
                )
                confirmation =
                    "Budget réinitialisé, dépenses archivées. Nouveau cycle démarré."
                adjustment = ""
                showResetConfirm = false
            },
            onDismiss = { showResetConfirm = false }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionCard(Icons.Default.EventRepeat, "Clôture hebdomadaire") {
            budget?.let {
                Text(
                    "Semaine actuelle : ${it.currentWeekIndex} / ${it.totalWeeks}",
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(Modifier.height(4.dp))
            }
            Text(
                "La clôture n'est possible que le vendredi (voir le journal " +
                    "en cas de refus).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = {
                    viewModel.closeCurrentWeek()
                    confirmation = "Demande de clôture envoyée (voir le journal)."
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Clôturer la semaine")
            }
        }

        SectionCard(Icons.Default.RestartAlt, "Réinitialisation du cycle") {
            Text(
                "Archive les dépenses en cours et redémarre un cycle " +
                    "(du 27 au 27) avec les revenus et charges du moment.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = adjustment,
                onValueChange = { adjustment = it },
                label = { Text("Ajustement éventuel (+ ou −)") },
                suffix = { Text("€") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = { showResetConfirm = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Réinitialiser le budget")
            }
        }

        confirmation?.let {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.secondaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    it,
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                )
            }
        }
    }
}
