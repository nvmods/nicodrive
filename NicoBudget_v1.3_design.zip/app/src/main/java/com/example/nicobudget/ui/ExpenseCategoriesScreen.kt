package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.data.model.ExpenseCategoryEntity
import com.example.nicobudget.ui.components.ConfirmDialog
import com.example.nicobudget.ui.components.EmptyHint
import com.example.nicobudget.ui.components.SectionHeader

@Composable
fun ExpenseCategoriesScreen(viewModel: BudgetViewModel) {
    val categories by viewModel.expenseCategoriesLiveData.observeAsState(emptyList())
    var name by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<ExpenseCategoryEntity?>(null) }

    toDelete?.let { category ->
        ConfirmDialog(
            title = "Supprimer la catégorie ?",
            text = "« ${category.name} » sera retirée de la liste. Les dépenses " +
                "existantes conservent leur libellé.",
            confirmLabel = "Supprimer",
            onConfirm = {
                viewModel.deleteCategory(category)
                toDelete = null
            },
            onDismiss = { toDelete = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(Icons.Default.Category, "Catégories de dépenses")

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nouvelle catégorie") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.addCategory(name.trim())
                        name = ""
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        }

        if (categories.isEmpty()) {
            EmptyHint("Aucune catégorie. Crée-en une pour saisir des dépenses.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories, key = { it.id }) { category ->
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                category.name,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { toDelete = category }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Supprimer",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
