package com.example.nicobudget.data.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.nicobudget.data.model.*

@Dao
interface DriveOrderDao {

    @Insert
    suspend fun insertOrder(order: DriveOrderEntity): Long

    @Insert
    suspend fun insertLines(lines: List<DriveOrderLineEntity>)

    @Query("SELECT * FROM drive_orders WHERE orderId = :orderId LIMIT 1")
    suspend fun findByOrderId(orderId: String): DriveOrderEntity?

    @Query("SELECT * FROM drive_orders ORDER BY date DESC, id DESC")
    fun getAllOrders(): LiveData<List<DriveOrderEntity>>

    @Query("SELECT * FROM drive_order_lines WHERE orderId = :orderRowId ORDER BY id")
    suspend fun getLines(orderRowId: Int): List<DriveOrderLineEntity>

    @Delete
    suspend fun deleteOrder(order: DriveOrderEntity)

    /** Total dépensé au Drive par mois. */
    @Query(
        """
        SELECT substr(date, 1, 7) AS month,
               COUNT(*)           AS orderCount,
               SUM(total)         AS total,
               SUM(savings)       AS savings
        FROM drive_orders
        GROUP BY month
        ORDER BY month DESC
        """
    )
    suspend fun getMonthlyTotals(): List<DriveMonthlyTotal>

    /** Quantités et dépense par mois pour un produit ("eau" -> 10 bouteilles). */
    @Query(
        """
        SELECT substr(o.date, 1, 7) AS month,
               SUM(l.quantity)      AS quantity,
               SUM(l.total)         AS total
        FROM drive_order_lines l
        JOIN drive_orders o ON o.id = l.orderId
        WHERE l.label LIKE '%' || :search || '%'
        GROUP BY month
        ORDER BY month DESC
        """
    )
    suspend fun getProductStats(search: String): List<DriveProductStat>

    /** Dépense par rayon sur un mois donné (yyyy-MM). */
    @Query(
        """
        SELECT l.section AS category, SUM(l.total) AS total
        FROM drive_order_lines l
        JOIN drive_orders o ON o.id = l.orderId
        WHERE substr(o.date, 1, 7) = :month
        GROUP BY l.section
        ORDER BY total DESC
        """
    )
    suspend fun getSectionTotalsForMonth(month: String): List<CategoryExpenseTotal>
}
