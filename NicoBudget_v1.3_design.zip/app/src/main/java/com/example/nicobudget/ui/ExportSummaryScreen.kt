package com.example.nicobudget.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.ui.components.SectionHeader
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.ui.text.font.FontFamily

@Composable
fun ExportSummaryScreen(viewModel: BudgetViewModel) {
    val context = LocalContext.current
    val summaryLiveData = remember { viewModel.getBudgetSummary() }
    val summary by summaryLiveData.observeAsState("Chargement du résumé…")
    var emailAddress by remember { mutableStateOf("destinataire@example.com") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader(Icons.AutoMirrored.Filled.Send, "Exporter le résumé")

        OutlinedTextField(
            value = emailAddress,
            onValueChange = { emailAddress = it },
            label = { Text("Adresse e-mail") },
            modifier = Modifier.fillMaxWidth()
        )

        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
            Text(
                summary,
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace
            )
        }

        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse(
                        "mailto:${Uri.encode(emailAddress)}" +
                            "?subject=${Uri.encode("Résumé hebdomadaire NicoBudget")}" +
                            "&body=${Uri.encode(summary)}"
                    )
                }

                try {
                    context.startActivity(
                        Intent.createChooser(intent, "Envoyer l'e-mail via…")
                    )
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(
                        context,
                        "Aucune application de messagerie trouvée.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = emailAddress.isNotBlank()
        ) {
            Text("Envoyer par e-mail")
        }
    }
}
