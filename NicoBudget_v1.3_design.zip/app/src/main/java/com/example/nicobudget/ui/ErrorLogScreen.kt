package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.BudgetViewModel
import com.example.nicobudget.ui.components.EmptyHint
import com.example.nicobudget.ui.components.SectionHeader

@Composable
fun ErrorLogScreen(viewModel: BudgetViewModel) {
    val errorLog by viewModel.errorLog.observeAsState(emptyList())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(
            Icons.Default.Terminal,
            "Journal (${errorLog.size})",
            trailing = {
                TextButton(onClick = { viewModel.clearErrorLog() }) {
                    Text("Vider")
                }
            }
        )

        if (errorLog.isEmpty()) {
            EmptyHint("Aucun message enregistré.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(errorLog) { message ->
                    val (container, content) = when {
                        "[ERROR]" in message ->
                            MaterialTheme.colorScheme.errorContainer to
                                MaterialTheme.colorScheme.onErrorContainer
                        "[WARNING]" in message ->
                            MaterialTheme.colorScheme.tertiaryContainer to
                                MaterialTheme.colorScheme.onTertiaryContainer
                        else ->
                            MaterialTheme.colorScheme.surfaceVariant to
                                MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = container,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            message,
                            modifier = Modifier.padding(10.dp),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = content
                        )
                    }
                }
            }
        }
    }
}
