package com.example.nicobudget.data.model

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.*
import com.example.nicobudget.data.db.*
import com.example.nicobudget.drive.DriveImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.math.RoundingMode
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class BudgetViewModel(
    application: Application,
    state: SavedStateHandle
) : AndroidViewModel(application) {

    private val db: AppDatabase = AppDatabase.getDatabase(application)
    private val monthlyBudgetDao: MonthlyBudgetDao = db.monthlyBudgetDao()
    private val fixedChargeDao: FixedChargeDao = db.fixedChargeDao()
    private val fixedIncomeDao: FixedIncomeDao = db.fixedIncomeDao()
    private val expenseDao: ExpenseDao = db.expenseDao()
    private val expenseCategoryDao: ExpenseCategoryDao = db.expenseCategoryDao()
    private val driveOrderDao: DriveOrderDao = db.driveOrderDao()

    private val _expensesByCategory = MutableLiveData<List<CategoryExpenseTotal>>()
    val expensesByCategory: LiveData<List<CategoryExpenseTotal>> = _expensesByCategory

    private val _budgetLiveData = MutableLiveData<MonthlyBudgetEntity?>()
    val budgetLiveData: LiveData<MonthlyBudgetEntity?> = _budgetLiveData

    private val _weeklyBudgetLiveData = MutableLiveData<Double>()
    val weeklyBudgetLiveData: LiveData<Double> get() = _weeklyBudgetLiveData

    val allExpensesLiveData = expenseDao.getAllExpenses()
    val fixedChargesLiveData: LiveData<List<FixedChargeEntity>> =
        fixedChargeDao.getAllFixedCharges()
    val incomesLiveData: LiveData<List<FixedIncomeEntity>> =
        fixedIncomeDao.getAllIncomes()
    val expenseCategoriesLiveData: LiveData<List<ExpenseCategoryEntity>> =
        expenseCategoryDao.getAllCategories()
    val driveOrdersLiveData: LiveData<List<DriveOrderEntity>> =
        driveOrderDao.getAllOrders()

    private val _errorLog = state.getLiveData("errorLog", emptyList<String>())
    val errorLog: LiveData<List<String>> get() = _errorLog

    companion object {
        /** Catégorie de dépense utilisée pour les commandes Drive importées. */
        const val DRIVE_CATEGORY = DriveImporter.DRIVE_CATEGORY
    }

    init {
        refreshBudget()
        calculateCurrentWeekBudget()
        loadExpensesByCategory()
    }

    // Miroir en mémoire du journal : logError() peut être appelé depuis des
    // threads IO ; un read-modify-write direct sur _errorLog.value perdrait
    // des messages (postValue coalesce les publications rapprochées).
    private val errorLogBuffer =
        java.util.Collections.synchronizedList(
            (_errorLog.value.orEmpty()).toMutableList()
        )

    private fun logError(message: String) {
        errorLogBuffer.add(message)
        _errorLog.postValue(errorLogBuffer.toList())
    }

    fun clearErrorLog() {
        errorLogBuffer.clear()
        _errorLog.postValue(emptyList())
    }

    fun addFixedCharge(name: String, amount: Double) {
        viewModelScope.launch {
            fixedChargeDao.insertCharge(FixedChargeEntity(name = name, amount = amount))
            updateDisposableLeftover()
        }
    }

    fun deleteFixedCharge(charge: FixedChargeEntity) {
        viewModelScope.launch {
            fixedChargeDao.deleteCharge(charge)
            updateDisposableLeftover()
        }
    }

    fun addIncome(title: String, amount: Double) {
        viewModelScope.launch {
            fixedIncomeDao.insertIncome(FixedIncomeEntity(title = title, amount = amount))
            updateDisposableLeftover()
        }
    }

    fun deleteIncome(income: FixedIncomeEntity) {
        viewModelScope.launch {
            fixedIncomeDao.deleteIncome(income)
            updateDisposableLeftover()
        }
    }

    fun addCategory(name: String) {
        viewModelScope.launch {
            expenseCategoryDao.insertCategory(ExpenseCategoryEntity(name = name))
        }
    }

    fun deleteCategory(category: ExpenseCategoryEntity) {
        viewModelScope.launch {
            expenseCategoryDao.deleteCategory(category)
        }
    }

    // ------------------------------------------------------------------
    // Leclerc Drive
    // ------------------------------------------------------------------

    /**
     * Importe un bon de commande Leclerc Drive (PDF) via [DriveImporter]
     * (logique partagée avec la synchro automatique en arrière-plan).
     * Idempotent : une commande déjà importée est refusée proprement.
     */
    fun importDrivePdf(uri: Uri, context: Context, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                DriveImporter.import(context, uri)
            }
            when (result) {
                is DriveImporter.Result.Imported ->
                    logError("[DEBUG] Drive ${result.orderId} importée.")
                is DriveImporter.Result.Failed ->
                    logError("[ERROR] Import Drive : ${result.message}")
                is DriveImporter.Result.Duplicate -> {}
            }
            updateDisposableLeftover()
            onResult(result.message)
        }
    }

    /** Supprime une commande Drive et la dépense budget liée. */
    fun deleteDriveOrder(order: DriveOrderEntity) {
        viewModelScope.launch {
            order.expenseId?.let { expId ->
                expenseDao.getAllExpensesNow()
                    .firstOrNull { it.id.toLong() == expId }
                    ?.let { expenseDao.deleteExpense(it) }
            }
            driveOrderDao.deleteOrder(order)   // lignes supprimées par CASCADE
            updateDisposableLeftover()
        }
    }

    suspend fun getDriveLines(orderRowId: Int): List<DriveOrderLineEntity> =
        driveOrderDao.getLines(orderRowId)

    suspend fun getDriveMonthlyTotals(): List<DriveMonthlyTotal> =
        driveOrderDao.getMonthlyTotals()

    suspend fun getDriveProductStats(search: String): List<DriveProductStat> =
        driveOrderDao.getProductStats(search)

    suspend fun getDriveSectionTotals(month: String): List<CategoryExpenseTotal> =
        driveOrderDao.getSectionTotalsForMonth(month)

    // ------------------------------------------------------------------
    // Budget
    // ------------------------------------------------------------------

    fun resetBudget(adjustment: Double = 0.0) {
        viewModelScope.launch {
            val currentMonthYear = getCurrentMonthYear()
            logError("[DEBUG] Reset du budget pour $currentMonthYear avec ajustement de $adjustment")

            val currentExpenses = expenseDao.getAllExpensesNow()
            val now = LocalDate.now().toString()

            currentExpenses.forEach { expense ->
                monthlyBudgetDao.insertArchivedExpense(
                    ExpenseArchiveEntity(
                        category = expense.category,
                        amount = expense.amount,
                        date = expense.date,
                        archivedAt = now
                    )
                )
            }

            expenseDao.deleteAllExpenses()
            logError("[DEBUG] ${currentExpenses.size} dépense(s) archivée(s), table courante vidée.")

            val totalIncome = fixedIncomeDao.getTotalIncome() ?: 0.0
            val totalCharges = fixedChargeDao.getTotalFixedCharges() ?: 0.0
            val newDisposableLeftover = totalIncome - totalCharges + adjustment
            val totalWeeks = getNumberOfWeeksInMonth()

            val existingBudget = monthlyBudgetDao.getBudgetBlocking(currentMonthYear)

            val updatedBudget = existingBudget?.copy(
                monthlyIncome = totalIncome,
                disposableLeftover = newDisposableLeftover,
                currentWeekIndex = 1,
                totalWeeks = totalWeeks
            ) ?: run {
                // Cycle budgétaire du 27 au 27 (cf. principes de fonctionnement §6).
                val today = LocalDate.now()
                val cycleStart =
                    if (today.dayOfMonth >= 27) today.withDayOfMonth(27)
                    else today.minusMonths(1).withDayOfMonth(27)
                val cycleEnd = cycleStart.plusMonths(1)
                MonthlyBudgetEntity(
                    title = "Budget $currentMonthYear",
                    monthYear = currentMonthYear,
                    monthlyIncome = totalIncome,
                    disposableLeftover = newDisposableLeftover,
                    currentWeekIndex = 1,
                    totalWeeks = totalWeeks,
                    startDate = cycleStart.toString(),
                    endDate = cycleEnd.toString()
                )
            }

            monthlyBudgetDao.upsertBudget(updatedBudget)
            refreshBudget()
            calculateCurrentWeekBudget()
            loadExpensesByCategory()
        }
    }

    private fun updateDisposableLeftover() {
        viewModelScope.launch {
            monthlyBudgetDao.updateDisposableLeftover()
            refreshBudget()
            calculateCurrentWeekBudget()
            loadExpensesByCategory()
        }
    }

    fun calculateCurrentWeekBudget() {
        viewModelScope.launch {
            val budget = monthlyBudgetDao.getBudgetBlocking(getCurrentMonthYear())
            if (budget != null) {
                val weeksLeft =
                    (budget.totalWeeks - budget.currentWeekIndex + 1).coerceAtLeast(1)
                val weeklyBudget =
                    (budget.disposableLeftover / weeksLeft).toBigDecimal()
                        .setScale(2, RoundingMode.HALF_EVEN)
                        .toDouble()
                _weeklyBudgetLiveData.postValue(weeklyBudget)
            } else {
                _weeklyBudgetLiveData.postValue(0.0)
                logError("[ERROR] Aucun budget trouvé pour calculer le weeklyBudget")
            }
        }
    }

    fun refreshBudget() {
        viewModelScope.launch {
            _budgetLiveData.postValue(monthlyBudgetDao.getBudgetById())
        }
    }

    fun addExpense(category: String, amount: Double) {
        viewModelScope.launch {
            expenseDao.insertExpense(
                ExpenseEntity(
                    date = LocalDate.now().format(DateTimeFormatter.ISO_DATE),
                    category = category,
                    amount = amount
                )
            )
            updateDisposableLeftover()
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            expenseDao.deleteExpense(expense)
            updateDisposableLeftover()
        }
    }

    fun loadExpensesByCategory() {
        viewModelScope.launch {
            _expensesByCategory.postValue(expenseDao.getTotalExpensesByCategory())
        }
    }

    private fun getCurrentMonthYear(): String {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM"))
    }

    private fun getNumberOfWeeksInMonth(): Int {
        return try {
            val today = LocalDate.now()
            val startDate = today.withDayOfMonth(27)
            val endDate = startDate.plusMonths(1)
            val firstMonday = startDate.with(java.time.DayOfWeek.MONDAY)
            val lastMonday = endDate.with(java.time.DayOfWeek.MONDAY)
            val weeks = java.time.temporal.ChronoUnit.WEEKS
                .between(firstMonday, lastMonday)
                .toInt() + 1
            logError("[DEBUG] Nombre de semaines entre $startDate et $endDate = $weeks")
            weeks
        } catch (e: Exception) {
            logError("[ERROR] Erreur dans getNumberOfWeeksInMonth(): ${e.message}")
            4
        }
    }

    fun closeCurrentWeek() {
        viewModelScope.launch {
            val budget = monthlyBudgetDao.getBudgetBlocking(getCurrentMonthYear())
            if (budget == null) {
                logError("[ERROR] Aucun budget actif trouvé, impossible de clôturer la semaine.")
                return@launch
            }

            if (LocalDate.now().dayOfWeek != java.time.DayOfWeek.FRIDAY) {
                logError("[WARNING] Aujourd'hui n'est pas un vendredi, la clôture ne sera pas effectuée.")
                return@launch
            }

            if (budget.currentWeekIndex >= budget.totalWeeks) {
                logError("[WARNING] Dernière semaine atteinte, pas d'incrémentation.")
                return@launch
            }

            val updatedBudget = budget.copy(
                currentWeekIndex = budget.currentWeekIndex + 1
            )
            monthlyBudgetDao.upsertBudget(updatedBudget)
            refreshBudget()
            calculateCurrentWeekBudget()
            logError("[DEBUG] Passage à la semaine ${updatedBudget.currentWeekIndex}")
        }
    }

    /**
     * Import CSV. Corrections vs version précédente :
     *  - I/O et insertions sur Dispatchers.IO (plus de lecture fichier sur le
     *    main thread), résultat renvoyé via [onResult] ;
     *  - insertions séquentielles : le compte rendu reflète l'état réel et
     *    updateDisposableLeftover() s'exécute après les insertions ;
     *  - séparateur ';' accepté, ce qui permet les montants français "12,50"
     *    sans casser le découpage des colonnes.
     */
    fun importFromCsv(uri: Uri, context: Context, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                        ?: return@withContext "Erreur lors de l'import : impossible d'ouvrir le fichier."

                    val lines = BufferedReader(InputStreamReader(inputStream))
                        .use { it.readLines() }

                    var successCount = 0
                    var errorCount = 0

                    lines.drop(1)
                        .filter { it.isNotBlank() }
                        .forEachIndexed { index, line ->
                            try {
                                val sep = if (';' in line) ';' else ','
                                val parts = line.split(sep)
                                if (parts.size < 5) {
                                    errorCount++
                                    logError("[WARNING] Ligne CSV ${index + 2} incomplète.")
                                    return@forEachIndexed
                                }

                                val type = parts[0].trim().lowercase()
                                val date = LocalDate.parse(parts[1].trim())
                                val libelle = parts[2].trim()
                                val montant =
                                    parts[3].trim().replace(',', '.').toDouble()
                                val categorie = parts[4].trim()

                                when (type) {
                                    "ressource" -> {
                                        fixedIncomeDao.insertIncome(
                                            FixedIncomeEntity(
                                                title = libelle, amount = montant
                                            )
                                        )
                                        successCount++
                                    }

                                    "charge" -> {
                                        fixedChargeDao.insertCharge(
                                            FixedChargeEntity(
                                                name = libelle, amount = montant
                                            )
                                        )
                                        successCount++
                                    }

                                    "operation" -> {
                                        expenseDao.insertExpense(
                                            ExpenseEntity(
                                                date = date.toString(),
                                                category = categorie,
                                                amount = montant
                                            )
                                        )
                                        successCount++
                                    }

                                    else -> {
                                        errorCount++
                                        logError(
                                            "[WARNING] Type CSV inconnu à la ligne " +
                                                "${index + 2}: $type"
                                        )
                                    }
                                }
                            } catch (e: Exception) {
                                errorCount++
                                Log.e("ImportCSV", "Erreur ligne CSV : ${e.message}", e)
                                logError(
                                    "[ERROR] Erreur CSV ligne ${index + 2}: ${e.message}"
                                )
                            }
                        }

                    "Import terminé : $successCount lignes ajoutées, " +
                        "$errorCount erreur(s)."
                } catch (e: Exception) {
                    Log.e("ImportCSV", "Échec de lecture CSV : ${e.message}", e)
                    logError("[ERROR] Échec de lecture CSV : ${e.message}")
                    "Erreur lors de l'import : ${e.message}"
                }
            }
            updateDisposableLeftover()
            onResult(result)
        }
    }

    fun getBudgetSummary(): LiveData<String> {
        val summaryLiveData = MutableLiveData<String>()

        viewModelScope.launch(Dispatchers.IO) {
            val budget = monthlyBudgetDao.getBudgetBlocking(getCurrentMonthYear())
            val charges = fixedChargeDao.getAllFixedChargesNow()
            val incomes = fixedIncomeDao.getAllIncomesNow()
            val expensesByCat = expenseDao.getTotalExpensesByCategoryNow()
            val weeklyBudget = _weeklyBudgetLiveData.value ?: 0.0
            val driveMonths = driveOrderDao.getMonthlyTotals()

            val builder = StringBuilder()
            builder.appendLine("Résumé NicoBudget")
            builder.appendLine("Mois : ${getCurrentMonthYear()}")
            builder.appendLine()
            builder.appendLine("Budget mensuel : ${budget?.monthlyIncome ?: 0.0} €")
            builder.appendLine("Restant disponible : ${budget?.disposableLeftover ?: 0.0} €")
            builder.appendLine("Budget hebdomadaire restant : $weeklyBudget €")
            builder.appendLine("Semaine actuelle : ${budget?.currentWeekIndex ?: 0} / ${budget?.totalWeeks ?: 0}")
            builder.appendLine()

            builder.appendLine("Revenus :")
            incomes.forEach { builder.appendLine("- ${it.title} : ${it.amount} €") }
            builder.appendLine()

            builder.appendLine("Charges fixes :")
            charges.forEach { builder.appendLine("- ${it.name} : ${it.amount} €") }
            builder.appendLine()

            builder.appendLine("Dépenses par catégorie :")
            expensesByCat.forEach {
                builder.appendLine("- ${it.category} : ${it.total} €")
            }

            driveMonths.firstOrNull { it.month == getCurrentMonthYear() }?.let {
                builder.appendLine()
                builder.appendLine("Leclerc Drive (${it.month}) :")
                builder.appendLine(
                    "- ${it.orderCount} commande(s), %.2f € dépensés, ".format(it.total) +
                        "%.2f € économisés".format(it.savings)
                )
            }

            summaryLiveData.postValue(builder.toString())
        }

        return summaryLiveData
    }

    suspend fun getArchivedExpenses(): List<ExpenseArchiveEntity> {
        return monthlyBudgetDao.getAllArchivedExpenses()
    }
}
