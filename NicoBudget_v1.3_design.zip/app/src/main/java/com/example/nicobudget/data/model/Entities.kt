package com.example.nicobudget.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monthly_budget")
data class MonthlyBudgetEntity(
    @PrimaryKey(autoGenerate = true) val revenueId: Int = 0,
    val title: String,
    val monthYear: String?,
    val monthlyIncome: Double,
    val disposableLeftover: Double,
    val currentWeekIndex: Int,
    val totalWeeks: Int,
    val startDate: String,
    val endDate: String
)

@Entity(tableName = "fixed_incomes")
data class FixedIncomeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val amount: Double
)

@Entity(tableName = "fixed_charges")
data class FixedChargeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val amount: Double
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val category: String,
    val amount: Double
)

@Entity(tableName = "expense_categories")
data class ExpenseCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String
)

@Entity(tableName = "expense_archive")
data class ExpenseArchiveEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String,
    val amount: Double,
    val date: String,
    val archivedAt: String
)

data class CategoryExpenseTotal(
    val category: String,
    val total: Double
)
