package com.example.nicobudget.util

import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun customButtonColorsBleu(): ButtonColors =
    ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))

@Composable
fun customButtonColorsRouge(): ButtonColors =
    ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))

@Composable
fun customButtonColorsVert(): ButtonColors =
    ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C))
