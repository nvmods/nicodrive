package com.example.nicobudget.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Palette "encre & menthe" : sobre, contrastée, moderne.
private val Ink = Color(0xFF0F2A43)          // bleu nuit profond
private val InkSoft = Color(0xFF2C4A6B)
private val Mint = Color(0xFF12B886)         // accent vert (argent qui rentre)
private val MintDark = Color(0xFF0CA678)
private val Coral = Color(0xFFE8590C)        // accent dépenses / alertes
private val Sand = Color(0xFFF8F5F0)         // fond chaud
private val Card = Color(0xFFFFFFFF)
private val OnSand = Color(0xFF1B2733)

private val LightColors = lightColorScheme(
    primary = Ink,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E4F5),
    onPrimaryContainer = Ink,
    secondary = Mint,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3F5EA),
    onSecondaryContainer = Color(0xFF063D2E),
    tertiary = Coral,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE3D3),
    onTertiaryContainer = Color(0xFF551E00),
    background = Sand,
    onBackground = OnSand,
    surface = Card,
    onSurface = OnSand,
    surfaceVariant = Color(0xFFEDE9E1),
    onSurfaceVariant = Color(0xFF52606C),
    outline = Color(0xFFB9C2CC),
    error = Color(0xFFB3261E),
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9FC2E8),
    onPrimary = Color(0xFF0A1C2E),
    primaryContainer = InkSoft,
    onPrimaryContainer = Color(0xFFD6E4F5),
    secondary = Color(0xFF63E2B7),
    onSecondary = Color(0xFF00382A),
    secondaryContainer = MintDark,
    onSecondaryContainer = Color(0xFFD3F5EA),
    tertiary = Color(0xFFFFB68F),
    onTertiary = Color(0xFF541F00),
    background = Color(0xFF10161C),
    onBackground = Color(0xFFE2E6EA),
    surface = Color(0xFF171F27),
    onSurface = Color(0xFFE2E6EA),
    surfaceVariant = Color(0xFF232D37),
    onSurfaceVariant = Color(0xFFAAB4BE),
    outline = Color(0xFF56606A),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

@Composable
fun NicoBudgetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Couleurs dynamiques Android 12+ ("Material You") si dispo
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }
    MaterialTheme(colorScheme = colorScheme, content = content)
}
