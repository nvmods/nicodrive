package com.example.nicobudget.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.nicobudget.data.model.*

@Database(
    entities = [
        MonthlyBudgetEntity::class,
        ExpenseEntity::class,
        FixedChargeEntity::class,
        ExpenseCategoryEntity::class,
        FixedIncomeEntity::class,
        ExpenseArchiveEntity::class,
        DriveOrderEntity::class,
        DriveOrderLineEntity::class
    ],
    version = 11,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun monthlyBudgetDao(): MonthlyBudgetDao
    abstract fun fixedChargeDao(): FixedChargeDao
    abstract fun fixedIncomeDao(): FixedIncomeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun expenseCategoryDao(): ExpenseCategoryDao
    abstract fun driveOrderDao(): DriveOrderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS expense_archive (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        category TEXT NOT NULL,
                        amount REAL NOT NULL,
                        date TEXT NOT NULL,
                        archivedAt TEXT NOT NULL
                    )
                    """.trimIndent()
                )
            }
        }

        private val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS drive_orders (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        orderId TEXT NOT NULL,
                        date TEXT NOT NULL,
                        time TEXT,
                        store TEXT,
                        productCount INTEGER NOT NULL,
                        total REAL NOT NULL,
                        savings REAL NOT NULL,
                        ticketLeclerc REAL NOT NULL,
                        expenseId INTEGER
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS index_drive_orders_orderId " +
                        "ON drive_orders(orderId)"
                )
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS drive_order_lines (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        orderId INTEGER NOT NULL,
                        section TEXT,
                        label TEXT NOT NULL,
                        quantity REAL NOT NULL,
                        unitPrice REAL NOT NULL,
                        total REAL NOT NULL,
                        FOREIGN KEY(orderId) REFERENCES drive_orders(id) ON DELETE CASCADE
                    )
                    """.trimIndent()
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_drive_order_lines_orderId " +
                        "ON drive_order_lines(orderId)"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS index_drive_order_lines_label " +
                        "ON drive_order_lines(label)"
                )
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nico_budget_db"
                )
                    .addMigrations(MIGRATION_9_10, MIGRATION_10_11)
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
