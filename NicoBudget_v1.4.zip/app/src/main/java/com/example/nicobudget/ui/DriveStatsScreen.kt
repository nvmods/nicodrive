package com.example.nicobudget.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.*
import com.example.nicobudget.ui.components.*
import kotlinx.coroutines.launch

/**
 * Statistiques Leclerc Drive : sélection du mois, top produits (avec
 * évolution au tap), répartition par rayon. Conçu pour rester lisible
 * même avec des centaines de produits différents.
 */
@Composable
fun DriveStatsScreen(viewModel: BudgetViewModel) {
    val scope = rememberCoroutineScope()

    var months by remember { mutableStateOf(emptyList<String>()) }
    var selectedMonth by remember { mutableStateOf<String?>(null) }
    var topProducts by remember { mutableStateOf(emptyList<DriveTopProduct>()) }
    var sections by remember { mutableStateOf(emptyList<CategoryExpenseTotal>()) }
    var evolutionOf by remember { mutableStateOf<String?>(null) }
    var evolution by remember { mutableStateOf(emptyList<DriveProductStat>()) }
    var byQuantity by remember { mutableStateOf(false) }

    fun loadMonth(month: String) {
        scope.launch {
            topProducts = viewModel.getDriveTopProducts(month, 15)
            sections = viewModel.getDriveSectionTotals(month)
        }
    }

    LaunchedEffect(Unit) {
        months = viewModel.getDriveMonths()
        months.firstOrNull()?.let {
            selectedMonth = it
            loadMonth(it)
        }
    }

    // ---------------- Dialogue d'évolution d'un produit ----------------
    evolutionOf?.let { label ->
        AlertDialog(
            onDismissRequest = { evolutionOf = null },
            title = {
                Text(label, style = MaterialTheme.typography.titleMedium)
            },
            text = {
                if (evolution.isEmpty()) {
                    Text("Pas d'historique pour ce produit.")
                } else {
                    val maxTotal = evolution.maxOf { it.total }
                    Column {
                        evolution.forEach { e ->
                            Column(Modifier.padding(vertical = 4.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(e.month)
                                    Text(
                                        "x%s — %s".format(
                                            if (e.quantity % 1.0 == 0.0)
                                                e.quantity.toInt().toString()
                                            else "%.3f".format(e.quantity),
                                            e.total.eur()
                                        ),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = {
                                        if (maxTotal > 0)
                                            (e.total / maxTotal).toFloat() else 0f
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.secondary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { evolutionOf = null }) { Text("Fermer") }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SectionHeader(Icons.Default.BarChart, "Stats Leclerc Drive")

        if (months.isEmpty()) {
            EmptyHint("Aucune commande importée pour l'instant.")
            return@Column
        }

        // ---------------- Sélecteur de mois ----------------
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(months) { month ->
                FilterChip(
                    selected = month == selectedMonth,
                    onClick = {
                        selectedMonth = month
                        loadMonth(month)
                    },
                    label = { Text(month) }
                )
            }
        }

        // ---------------- Top produits ----------------
        SectionCard(
            Icons.Default.EmojiEvents,
            "Top produits",
            trailing = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (byQuantity) "Quantité" else "Dépense",
                        style = MaterialTheme.typography.labelMedium
                    )
                    Spacer(Modifier.width(6.dp))
                    Switch(
                        checked = byQuantity,
                        onCheckedChange = { byQuantity = it }
                    )
                }
            }
        ) {
            if (topProducts.isEmpty()) {
                EmptyHint("Aucun produit sur ce mois.")
            } else {
                val ranked =
                    if (byQuantity) topProducts.sortedByDescending { it.quantity }
                    else topProducts
                val maxValue =
                    if (byQuantity) ranked.maxOf { it.quantity }
                    else ranked.maxOf { it.total }
                Text(
                    "Tape un produit pour voir son évolution.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                ranked.forEachIndexed { index, p ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                evolutionOf = p.label
                                scope.launch {
                                    evolution =
                                        viewModel.getDriveProductEvolution(p.label)
                                }
                            }
                            .padding(vertical = 5.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "${index + 1}. ${p.label}",
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (byQuantity)
                                    "x%s".format(
                                        if (p.quantity % 1.0 == 0.0)
                                            p.quantity.toInt().toString()
                                        else "%.3f".format(p.quantity)
                                    )
                                else p.total.eur(),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = {
                                val v = if (byQuantity) p.quantity else p.total
                                if (maxValue > 0) (v / maxValue).toFloat() else 0f
                            },
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.secondary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }
        }

        // ---------------- Répartition par rayon ----------------
        SectionCard(Icons.Default.Storefront, "Répartition par rayon") {
            if (sections.isEmpty()) {
                EmptyHint("Aucune donnée de rayon sur ce mois.")
            } else {
                val totalMonth = sections.sumOf { it.total }
                sections.forEach { s ->
                    Column(Modifier.padding(vertical = 5.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                s.category,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Text(
                                "%s (%.0f %%)".format(
                                    s.total.eur(),
                                    if (totalMonth > 0)
                                        s.total / totalMonth * 100 else 0.0
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = {
                                if (totalMonth > 0)
                                    (s.total / totalMonth).toFloat() else 0f
                            },
                            modifier = Modifier.fillMaxWidth(),
                            color = MaterialTheme.colorScheme.tertiary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    }
                }
            }
        }
    }
}
