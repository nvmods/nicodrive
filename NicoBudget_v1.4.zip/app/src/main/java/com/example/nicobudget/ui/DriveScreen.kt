package com.example.nicobudget.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.nicobudget.data.model.*
import com.example.nicobudget.drive.DriveMailSync
import com.example.nicobudget.drive.DriveSyncWorker
import com.example.nicobudget.ui.components.eur
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun DriveScreen(
    viewModel: BudgetViewModel,
    pendingPdfUri: Uri? = null,
    onPendingConsumed: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val orders by viewModel.driveOrdersLiveData.observeAsState(emptyList())
    var status by remember { mutableStateOf<String?>(null) }
    var monthlyTotals by remember { mutableStateOf(emptyList<DriveMonthlyTotal>()) }
    var expandedOrderId by remember { mutableStateOf<Int?>(null) }
    var expandedLines by remember { mutableStateOf(emptyList<DriveOrderLineEntity>()) }
    var search by remember { mutableStateOf("") }
    var productStats by remember { mutableStateOf(emptyList<DriveProductStat>()) }
    var orderToDelete by remember { mutableStateOf<DriveOrderEntity?>(null) }
    var showConfig by remember { mutableStateOf(false) }
    var syncing by remember { mutableStateOf(false) }
    var autoSync by remember { mutableStateOf(DriveMailSync.isAutoSync(context)) }

    fun refreshTotals() {
        scope.launch { monthlyTotals = viewModel.getDriveMonthlyTotals() }
    }

    LaunchedEffect(orders) { refreshTotals() }

    LaunchedEffect(pendingPdfUri) {
        pendingPdfUri?.let { uri ->
            viewModel.importDrivePdf(uri, context) { status = it }
            onPendingConsumed()
        }
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) {
            status = "Aucun fichier sélectionné."
        } else {
            uris.forEach { uri ->
                viewModel.importDrivePdf(uri, context) { msg -> status = msg }
            }
        }
    }

    fun syncFromMail() {
        val config = DriveMailSync.loadConfig(context)
        if (config == null) {
            showConfig = true
            return
        }
        syncing = true
        status = "Connexion à la boîte mail…"
        scope.launch {
            try {
                val report = withContext(Dispatchers.IO) {
                    DriveMailSync.sync(context, config)
                }
                status = "${report.mailsScanned} mails scannés, " +
                    "${report.leclercMails} Leclerc, " +
                    "${report.pdfs.size} bon(s) de commande récupéré(s)." +
                    (report.failures.firstOrNull()?.let { "\nDétail : $it" } ?: "")
                report.pdfs.forEach { file ->
                    viewModel.importDrivePdf(Uri.fromFile(file), context) {
                        status = it
                    }
                }
            } catch (e: Exception) {
                status = "Erreur mail : ${e.message}"
            } finally {
                syncing = false
            }
        }
    }

    if (showConfig) {
        var user by remember {
            mutableStateOf(DriveMailSync.loadConfig(context)?.user ?: "")
        }
        var password by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showConfig = false },
            title = { Text("Compte SFR Mail") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Identifiants stockés chiffrés sur le téléphone, " +
                            "utilisés uniquement pour lire les mails Leclerc " +
                            "(imap.sfr.fr)."
                    )
                    OutlinedTextField(
                        value = user,
                        onValueChange = { user = it },
                        label = { Text("Adresse SFR complète") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Mot de passe") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        DriveMailSync.saveConfig(
                            context,
                            DriveMailSync.MailConfig(
                                "imap.sfr.fr", user.trim(), password
                            )
                        )
                        showConfig = false
                        syncFromMail()
                    },
                    enabled = user.isNotBlank() && password.isNotBlank()
                ) { Text("Enregistrer et vérifier") }
            },
            dismissButton = {
                TextButton(onClick = { showConfig = false }) { Text("Annuler") }
            }
        )
    }

    orderToDelete?.let { order ->
        AlertDialog(
            onDismissRequest = { orderToDelete = null },
            title = { Text("Supprimer la commande ?") },
            text = {
                Text(
                    "La commande n°${order.orderId} et la dépense budget " +
                        "associée (${order.total.eur()}) seront supprimées."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteDriveOrder(order)
                    orderToDelete = null
                }) { Text("Supprimer") }
            },
            dismissButton = {
                TextButton(onClick = { orderToDelete = null }) { Text("Annuler") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.ShoppingCart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Leclerc Drive",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                IconButton(onClick = { showConfig = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Config mail")
                }
            }
        }

        item {
            Button(
                onClick = { syncFromMail() },
                enabled = !syncing,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (syncing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(if (syncing) "Vérification…" else "Vérifier les commandes (mail)")
            }
        }

        item {
            OutlinedButton(
                onClick = { launcher.launch(arrayOf("application/pdf")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Importer des PDF manuellement")
            }
        }

        item {
            Surface(
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Synchro automatique",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Text(
                            "Vérifie les mails toutes les 6 h",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = autoSync,
                        onCheckedChange = { enabled ->
                            if (enabled && DriveMailSync.loadConfig(context) == null) {
                                showConfig = true
                            } else {
                                autoSync = enabled
                                DriveMailSync.setAutoSync(context, enabled)
                                if (enabled) DriveSyncWorker.schedule(context)
                                else DriveSyncWorker.cancel(context)
                            }
                        }
                    )
                }
            }
        }

        status?.let { s ->
            item {
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        s,
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        if (monthlyTotals.isNotEmpty()) {
            item {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "Dépenses Drive par mois",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(8.dp))
                        monthlyTotals.take(6).forEach { m ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    "${m.month}  ·  ${m.orderCount} cmd",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    m.total.eur(),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            if (m.savings > 0.0) {
                                Text(
                                    "dont ${m.savings.eur()} économisés",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = search,
                onValueChange = {
                    search = it
                    if (it.isBlank()) productStats = emptyList()
                },
                label = { Text("Rechercher un produit (ex : eau)") },
                trailingIcon = {
                    IconButton(onClick = {
                        scope.launch {
                            productStats =
                                if (search.isBlank()) emptyList()
                                else viewModel.getDriveProductStats(search.trim())
                        }
                    }) { Icon(Icons.Default.Search, contentDescription = "Rechercher") }
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (productStats.isNotEmpty()) {
            item {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "« $search » par mois",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(8.dp))
                        productStats.forEach { p ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.month, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "x%s — %.2f €".format(
                                        if (p.quantity % 1.0 == 0.0)
                                            p.quantity.toInt().toString()
                                        else "%.3f".format(p.quantity),
                                        p.total
                                    ),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                "Commandes (${orders.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }

        items(orders, key = { it.id }) { order ->
            val expanded = expandedOrderId == order.id
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (expanded) {
                            expandedOrderId = null
                        } else {
                            expandedOrderId = order.id
                            scope.launch {
                                expandedLines = viewModel.getDriveLines(order.id)
                            }
                        }
                    }
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "${order.date} — ${order.total.eur()}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "n°${order.orderId} · ${order.productCount} produits" +
                                    (order.store?.let { " · $it" } ?: ""),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { orderToDelete = order }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Supprimer",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                            Icon(
                                if (expanded) Icons.Default.ExpandLess
                                else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                        }
                    }

                    if (expanded) {
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(8.dp))
                        expandedLines.forEach { l ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    l.label,
                                    modifier = Modifier.weight(1f),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    "x%s  %.2f €".format(
                                        if (l.quantity % 1.0 == 0.0)
                                            l.quantity.toInt().toString()
                                        else "%.3f".format(l.quantity),
                                        l.total
                                    ),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        if (order.savings > 0.0 || order.ticketLeclerc > 0.0) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Économies : %.2f € · Ticket E.Leclerc : %.2f €"
                                    .format(order.savings, order.ticketLeclerc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }
}
